# Gym Management System

IronFit Gym is a Flask-based gym management system built for a small university project. It runs locally with SQLite, supports class booking and member management, includes a responsive admin dashboard, and keeps all primary UI assets inside the repository so the app works without CDN access at runtime.

## Project Overview

The application helps a gym manage:
- membership plans
- trainer profiles
- class schedules
- class bookings
- member records
- booking review from an admin dashboard

The project is intentionally modest in scope but complete enough for an exam demo.

## Technology Stack

- Python 3.11+
- Flask
- Flask-SQLAlchemy
- Flask-WTF
- SQLite
- Jinja2 templates
- Bootstrap 5 (vendored locally)
- pytest
- pytest-cov

## Features

### Public Features
- Homepage with gym overview, featured plans, trainers, classes, and testimonials
- Membership plans page
- Trainer listing page
- Class schedule with filters for class type, trainer, difficulty, and available spots
- Class detail page
- Booking form for classes

### Admin Features
- Session-based admin login
- Dashboard summary for members, trainers, plans, classes, and bookings
- Member CRUD
- Trainer management
- Membership plan management
- Fitness class management
- Booking status updates

## Project Structure

```text
gym-management-system/
├── app/
│   ├── __init__.py
│   ├── forms.py
│   ├── models.py
│   ├── routes.py
│   ├── static/
│   │   ├── css/
│   │   ├── images/
│   │   ├── js/
│   │   └── vendor/
│   └── templates/
│       ├── admin/
│       ├── base.html
│       ├── booking.html
│       ├── class_detail.html
│       ├── classes.html
│       ├── index.html
│       ├── plans.html
│       ├── trainers.html
│       ├── 404.html
│       └── 500.html
├── tests/
│   ├── conftest.py
│   ├── test_forms.py
│   ├── test_models.py
│   └── test_routes.py
├── .gitignore
├── config.py
├── README.md
├── requirements.txt
├── run.py
└── seed.py
```

## Setup Instructions

### 1. Clone the repository

```bash
git clone [repo-url]
cd gym-management-system
```

### 2. Create and activate a virtual environment

macOS or Linux:

```bash
python -m venv venv
source venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

## How To Run Locally

### Seed the database

```bash
python seed.py
```

### Start the application

```bash
python run.py
```

Then open:

```text
http://127.0.0.1:5000
```

## How To Run Tests

Run the full suite:

```bash
python -m pytest -v
```

Run with coverage:

```bash
python -m pytest --cov=app --cov-report=term-missing
```

Current verified result:
- 19 tests passing
- 92% total coverage

## Configuration

These environment variables are supported:

- `SECRET_KEY`
- `DATABASE_URL`
- `GYM_NAME`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

Default local admin credentials:

```text
Username: admin
Password: admin123
```

## Database Schema Overview

### Member
- id
- first_name
- last_name
- email
- phone
- membership_plan_id
- start_date
- end_date
- status
- created_at

### MembershipPlan
- id
- name
- price
- duration_days
- description
- benefits
- created_at

### Trainer
- id
- first_name
- last_name
- specialty
- experience_years
- email
- phone
- bio
- image_url

### FitnessClass
- id
- title
- class_type
- trainer_id
- difficulty_level
- scheduled_at
- duration_minutes
- capacity
- description

### Booking
- id
- fitness_class_id
- customer_name
- email
- phone
- message
- status
- submitted_at

## Route Documentation

### Public Routes
- `/` : homepage
- `/plans` : membership plans
- `/trainers` : trainer listing
- `/classes` : class schedule and filters
- `/classes/<id>` : class details
- `/book/<class_id>` : class booking form

### Admin Routes
- `/admin/login` : admin sign-in
- `/admin/logout` : admin sign-out
- `/admin` : dashboard
- `/admin/members` : member list
- `/admin/members/add` : add member
- `/admin/members/<id>/edit` : edit member
- `/admin/members/<id>/delete` : delete member
- `/admin/trainers` : manage trainers
- `/admin/trainers/<id>/delete` : delete trainer
- `/admin/plans` : manage plans
- `/admin/plans/<id>/delete` : delete plan
- `/admin/classes` : manage classes
- `/admin/classes/<id>/delete` : delete class
- `/admin/bookings` : manage booking status

## Seed Data Instructions

The seed script creates:
- 4 membership plans
- 5 trainers
- 8 fitness classes
- 10 members
- 5 sample bookings

To reset and reseed the database:

```bash
python seed.py
```

The script drops all tables, recreates them, and inserts fresh demo data.

## Screenshot Instructions

Use the following exact sequence after running `python seed.py` and `python run.py`.

### 1. Homepage
- Open `http://127.0.0.1:5000/`
- Capture the hero section and featured content cards

### 2. Membership plans page
- Open `http://127.0.0.1:5000/plans`
- Capture all four plans in the grid

### 3. Class schedule with filters
- Open `http://127.0.0.1:5000/classes`
- Select a class type or trainer filter
- Capture the filtered schedule results

### 4. Booking form
- Open any class detail page or go directly from the classes page
- Click `Book now`
- Capture the booking form with class summary visible

### 5. Admin dashboard
- Open `http://127.0.0.1:5000/admin/login`
- Sign in with the admin credentials
- Capture the dashboard stats and recent activity tables

### 6. Test suite passing
- Run:

```bash
python -m pytest -v
```

- Capture the terminal showing all tests passing

## Security Notes

- CSRF protection is enabled for forms
- Flask-WTF validates inputs
- SQLAlchemy ORM is used for database access
- Admin credentials can be overridden with environment variables
- Custom 404 and 500 error pages are included

## GitHub Repository Placeholder

Replace this placeholder with your final repository URL:

```text
https://github.com/your-username/gym-management-system
```
