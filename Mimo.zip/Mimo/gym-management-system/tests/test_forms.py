from werkzeug.datastructures import MultiDict

from app.forms import BookingForm, LoginForm, MemberForm


def test_booking_form_validates(app):
    with app.test_request_context():
        form = BookingForm(
            formdata=MultiDict(
                {
                    "customer_name": "Taylor Adams",
                    "email": "taylor@example.com",
                    "phone": "1234567890",
                    "message": "Please save my spot",
                }
            )
        )
        assert form.validate()


def test_booking_form_rejects_invalid_email(app):
    with app.test_request_context():
        form = BookingForm(
            formdata=MultiDict(
                {
                    "customer_name": "Taylor Adams",
                    "email": "invalid-email",
                    "phone": "1234567890",
                }
            )
        )
        assert not form.validate()
        assert form.email.errors


def test_member_form_requires_all_fields(app):
    with app.test_request_context():
        form = MemberForm(formdata=MultiDict({}))
        form.membership_plan_id.choices = [(1, "Basic")]
        assert not form.validate()
        assert form.first_name.errors
        assert form.membership_plan_id.errors


def test_login_form_requires_credentials(app):
    with app.test_request_context():
        form = LoginForm(formdata=MultiDict({"username": "", "password": ""}))
        assert not form.validate()
