from datetime import date, timedelta

from app.models import Booking, FitnessClass, Member, MembershipPlan, Trainer, db


def test_model_creation_and_relationships(app):
    with app.app_context():
        plan = MembershipPlan(
            name="Starter",
            price=20,
            duration_days=30,
            description="Starter plan",
            benefits="Gym floor\nLocker",
        )
        trainer = Trainer(
            first_name="Ari",
            last_name="Lane",
            specialty="Cardio",
            experience_years=4,
            email="ari@example.com",
            phone="12345",
            bio="Cardio trainer",
            image_url="https://example.com/ari.jpg",
        )
        db.session.add_all([plan, trainer])
        db.session.flush()
        fitness_class = FitnessClass(
            title="Cardio Burn",
            class_type="Cardio",
            trainer_id=trainer.id,
            difficulty_level="Intermediate",
            scheduled_at=date.today(),
            duration_minutes=45,
            capacity=12,
            description="Fast-paced cardio.",
        )
        member = Member(
            first_name="Nina",
            last_name="Hall",
            email="nina@example.com",
            phone="67890",
            membership_plan_id=plan.id,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=30),
            status="active",
        )
        db.session.add_all([fitness_class, member])
        db.session.flush()
        booking = Booking(
            fitness_class_id=fitness_class.id,
            customer_name="Client One",
            email="client@example.com",
            phone="5551234",
            message="See you there",
        )
        db.session.add(booking)
        db.session.commit()

        assert plan.benefit_list == ["Gym floor", "Locker"]
        assert trainer.full_name == "Ari Lane"
        assert member.membership_plan.name == "Starter"
        assert fitness_class.available_spots == 11
        assert booking.fitness_class.title == "Cardio Burn"
