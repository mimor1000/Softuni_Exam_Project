from app.models import Booking, Member, db


def test_homepage_loads(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"IronFit Gym" in response.data


def test_plans_page_loads_with_seeded_data(client, seeded_data):
    response = client.get("/plans")
    assert response.status_code == 200
    assert b"Basic Plan" in response.data


def test_trainers_page_loads(client, seeded_data):
    response = client.get("/trainers")
    assert response.status_code == 200
    assert b"Ava Stone" in response.data


def test_classes_page_loads_and_filters(client, seeded_data):
    response = client.get("/classes?type=Yoga")
    assert response.status_code == 200
    assert b"Morning Yoga" in response.data
    assert b"Strength Basics" not in response.data


def test_class_detail_page_loads(client, seeded_data):
    response = client.get(f"/classes/{seeded_data['class_ids'][0]}")
    assert response.status_code == 200
    assert b"Morning Yoga" in response.data


def test_booking_form_submission(client, seeded_data, app):
    fitness_class_id = seeded_data["class_ids"][0]
    response = client.post(
        f"/book/{fitness_class_id}",
        data={
            "customer_name": "Jamie Rivers",
            "email": "jamie@example.com",
            "phone": "1231231234",
            "message": "Excited for class",
        },
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Your booking has been received." in response.data

    with app.app_context():
        assert db.session.scalar(db.select(Booking).where(Booking.email == "jamie@example.com"))


def test_invalid_booking_form_shows_errors(client, seeded_data):
    fitness_class_id = seeded_data["class_ids"][0]
    response = client.post(
        f"/book/{fitness_class_id}",
        data={
            "customer_name": "",
            "email": "not-an-email",
            "phone": "",
        },
    )
    assert response.status_code == 200
    assert b"This field is required." in response.data


def test_booking_rejected_when_class_is_full(client, seeded_data, app):
    fitness_class_id = seeded_data["class_ids"][0]
    with app.app_context():
        for index in range(9):
            db.session.add(
                Booking(
                    fitness_class_id=fitness_class_id,
                    customer_name=f"Waitlist {index}",
                    email=f"waitlist{index}@example.com",
                    phone=f"90000000{index}",
                    status="confirmed",
                )
            )
        db.session.commit()

    response = client.post(
        f"/book/{fitness_class_id}",
        data={
            "customer_name": "Last Spot",
            "email": "last@example.com",
            "phone": "1231231234",
            "message": "Trying to join",
        },
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"This class is fully booked." in response.data


def test_admin_login_dashboard_and_logout_flow(client, seeded_data):
    invalid_response = client.post(
        "/admin/login",
        data={"username": "wrong", "password": "wrong"},
        follow_redirects=True,
    )
    assert invalid_response.status_code == 200
    assert b"Invalid credentials." in invalid_response.data

    login_response = client.post(
        "/admin/login",
        data={"username": "admin", "password": "admin123"},
        follow_redirects=True,
    )
    assert login_response.status_code == 200
    assert b"Manage members, trainers, plans, classes, and bookings" in login_response.data

    logout_response = client.post("/admin/logout", data={"submit": "Confirm"}, follow_redirects=True)
    assert logout_response.status_code == 200
    assert b"You have been signed out." in logout_response.data


def test_admin_member_crud(admin_client, seeded_data, app):
    plan_id = seeded_data["plan_ids"][0]
    add_response = admin_client.post(
        "/admin/members/add",
        data={
            "first_name": "Lara",
            "last_name": "Hill",
            "email": "lara@example.com",
            "phone": "2223334444",
            "membership_plan_id": plan_id,
            "start_date": "2026-01-01",
            "end_date": "2026-02-01",
            "status": "active",
        },
        follow_redirects=True,
    )
    assert add_response.status_code == 200
    assert b"Member saved successfully." in add_response.data

    with app.app_context():
        member = db.session.scalar(db.select(Member).where(Member.email == "lara@example.com"))
        assert member is not None
        member_id = member.id

    edit_response = admin_client.post(
        f"/admin/members/{member_id}/edit",
        data={
            "first_name": "Lara",
            "last_name": "Stone",
            "email": "lara@example.com",
            "phone": "2223334444",
            "membership_plan_id": plan_id,
            "start_date": "2026-01-01",
            "end_date": "2026-02-01",
            "status": "inactive",
        },
        follow_redirects=True,
    )
    assert edit_response.status_code == 200
    assert b"Member saved successfully." in edit_response.data

    delete_response = admin_client.post(
        f"/admin/members/{member_id}/delete",
        data={"submit": "Confirm"},
        follow_redirects=True,
    )
    assert delete_response.status_code == 200
    assert b"Member deleted." in delete_response.data

    with app.app_context():
        assert db.session.get(Member, member_id) is None


def test_admin_management_pages_and_updates(admin_client, seeded_data, app):
    trainers_page = admin_client.get("/admin/trainers")
    plans_page = admin_client.get("/admin/plans")
    classes_page = admin_client.get("/admin/classes")
    bookings_page = admin_client.get("/admin/bookings")

    assert trainers_page.status_code == 200
    assert plans_page.status_code == 200
    assert classes_page.status_code == 200
    assert bookings_page.status_code == 200

    add_trainer = admin_client.post(
        "/admin/trainers",
        data={
            "first_name": "Zara",
            "last_name": "Miles",
            "specialty": "Mobility",
            "experience_years": 4,
            "email": "zara@example.com",
            "phone": "555777999",
            "bio": "Mobility coach",
            "image_url": "/static/images/trainer-1.svg",
        },
        follow_redirects=True,
    )
    assert b"Trainer saved successfully." in add_trainer.data

    add_plan = admin_client.post(
        "/admin/plans",
        data={
            "name": "Weekend Plan",
            "price": 35,
            "duration_days": 14,
            "description": "Short-term access",
            "benefits": "Weekend access\nLocker room",
        },
        follow_redirects=True,
    )
    assert b"Membership plan saved successfully." in add_plan.data

    add_class = admin_client.post(
        "/admin/classes",
        data={
            "title": "Lunch Express",
            "class_type": "Cardio",
            "trainer_id": seeded_data["trainer_ids"][0],
            "difficulty_level": "Beginner",
            "scheduled_at": "2026-06-30T12:30",
            "duration_minutes": 30,
            "capacity": 12,
            "description": "Quick midday workout.",
        },
        follow_redirects=True,
    )
    assert b"Fitness class saved successfully." in add_class.data

    update_booking = admin_client.post(
        "/admin/bookings",
        data={"booking_id": seeded_data["booking_id"], "status": "confirmed"},
        follow_redirects=True,
    )
    assert b"Booking updated." in update_booking.data

    plan_delete = admin_client.post(
        f"/admin/plans/{seeded_data['plan_ids'][0]}/delete",
        data={"submit": "Confirm"},
        follow_redirects=True,
    )
    assert b"Cannot delete a plan that is assigned to members." in plan_delete.data


def test_admin_dashboard_requires_login(client):
    response = client.get("/admin", follow_redirects=False)
    assert response.status_code == 302
    assert "/admin/login" in response.headers["Location"]


def test_not_found_page(client):
    response = client.get("/missing-page")
    assert response.status_code == 404
    assert b"could not be found" in response.data or b"Page not found" in response.data


def test_empty_database_pages(client):
    for route in ["/", "/plans", "/trainers", "/classes"]:
        response = client.get(route)
        assert response.status_code == 200
