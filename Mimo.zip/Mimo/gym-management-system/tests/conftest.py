from datetime import date, datetime, timedelta

import pytest

from app import create_app
from app.models import Booking, FitnessClass, Member, MembershipPlan, Trainer, db
from config import TestingConfig


@pytest.fixture
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()
        db.engine.dispose()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def seeded_data(app):
    with app.app_context():
        plan = MembershipPlan(
            name="Basic Plan",
            price=30,
            duration_days=30,
            description="Basic membership access.",
            benefits="Gym floor access\nLocker access",
        )
        premium = MembershipPlan(
            name="Premium Plan",
            price=55,
            duration_days=30,
            description="Unlimited classes membership.",
            benefits="Unlimited classes\nPriority booking",
        )
        trainer = Trainer(
            first_name="Ava",
            last_name="Stone",
            specialty="Yoga",
            experience_years=5,
            email="ava@example.com",
            phone="1234567890",
            bio="Mobility and recovery specialist.",
            image_url="https://example.com/ava.jpg",
        )
        second_trainer = Trainer(
            first_name="Noah",
            last_name="Cole",
            specialty="Strength",
            experience_years=7,
            email="noah@example.com",
            phone="1234567891",
            bio="Strength coach.",
            image_url="https://example.com/noah.jpg",
        )
        db.session.add_all([plan, premium, trainer, second_trainer])
        db.session.flush()

        fitness_class = FitnessClass(
            title="Morning Yoga",
            class_type="Yoga",
            trainer_id=trainer.id,
            difficulty_level="Beginner",
            scheduled_at=datetime.now() + timedelta(days=1),
            duration_minutes=60,
            capacity=10,
            description="A calm mobility class.",
        )
        strength_class = FitnessClass(
            title="Strength Basics",
            class_type="Strength Training",
            trainer_id=second_trainer.id,
            difficulty_level="Intermediate",
            scheduled_at=datetime.now() + timedelta(days=2),
            duration_minutes=50,
            capacity=8,
            description="Learn foundational lifting.",
        )
        member = Member(
            first_name="John",
            last_name="Doe",
            email="john@example.com",
            phone="999888777",
            membership_plan_id=plan.id,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=30),
            status="active",
        )
        db.session.add_all([fitness_class, strength_class, member])
        db.session.flush()
        booking = Booking(
            fitness_class_id=fitness_class.id,
            customer_name="Guest User",
            email="guest@example.com",
            phone="1010101010",
            message="Looking forward to it",
            status="pending",
        )
        db.session.add(booking)
        db.session.commit()
        return {
            "plan_ids": [plan.id, premium.id],
            "trainer_ids": [trainer.id, second_trainer.id],
            "class_ids": [fitness_class.id, strength_class.id],
            "member_id": member.id,
            "booking_id": booking.id,
        }


@pytest.fixture
def admin_client(client):
    with client.session_transaction() as session:
        session["is_admin_authenticated"] = True
    return client
