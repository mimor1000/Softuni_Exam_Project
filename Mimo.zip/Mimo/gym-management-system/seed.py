from datetime import date, datetime, timedelta

from app import create_app
from app.models import Booking, FitnessClass, Member, MembershipPlan, Trainer, db


app = create_app()


def reset_database():
    db.drop_all()
    db.create_all()


def create_plans():
    plans = [
        MembershipPlan(
            name="Basic Plan",
            price=29.99,
            duration_days=30,
            description="Essential gym floor access for independent training.",
            benefits="Gym floor access\nLocker room access\n1 fitness assessment\nEmail support",
        ),
        MembershipPlan(
            name="Premium Plan",
            price=54.99,
            duration_days=30,
            description="Unlimited classes with standard membership benefits.",
            benefits="Unlimited group classes\nGym floor access\nProgress tracking\nPriority support",
        ),
        MembershipPlan(
            name="Personal Training Plan",
            price=99.99,
            duration_days=30,
            description="For members who want guided coaching and accountability.",
            benefits="4 personal training sessions\nCustom workout plan\nNutrition check-in\nUnlimited gym access",
        ),
        MembershipPlan(
            name="Student Flex Plan",
            price=39.99,
            duration_days=45,
            description="Flexible access window for university schedules.",
            benefits="Flexible 45-day access\n2 guest passes\nWeekend classes\nMobile schedule access",
        ),
    ]
    db.session.add_all(plans)
    db.session.flush()
    return plans


def create_trainers():
    trainers = [
        Trainer(
            first_name="Ava",
            last_name="Martinez",
            specialty="Boxing Conditioning",
            experience_years=8,
            email="ava.martinez@ironfit.local",
            phone="+1 555 0101",
            bio="Builds sharp footwork, core control, and high-intensity boxing sessions.",
            image_url="/static/images/trainer-1.svg",
        ),
        Trainer(
            first_name="Noah",
            last_name="Reed",
            specialty="Strength Training",
            experience_years=10,
            email="noah.reed@ironfit.local",
            phone="+1 555 0102",
            bio="Focuses on foundational strength, safe barbell progressions, and movement quality.",
            image_url="/static/images/trainer-2.svg",
        ),
        Trainer(
            first_name="Mina",
            last_name="Park",
            specialty="Yoga Mobility",
            experience_years=6,
            email="mina.park@ironfit.local",
            phone="+1 555 0103",
            bio="Leads mobility-first yoga sessions that support recovery and long-term consistency.",
            image_url="/static/images/trainer-3.svg",
        ),
        Trainer(
            first_name="Ethan",
            last_name="Brooks",
            specialty="HIIT and Cardio",
            experience_years=7,
            email="ethan.brooks@ironfit.local",
            phone="+1 555 0104",
            bio="Designs fast-paced HIIT blocks that improve stamina and conditioning.",
            image_url="/static/images/trainer-4.svg",
        ),
        Trainer(
            first_name="Layla",
            last_name="Hassan",
            specialty="Functional Training",
            experience_years=9,
            email="layla.hassan@ironfit.local",
            phone="+1 555 0105",
            bio="Combines athletic drills, balance work, and practical full-body programming.",
            image_url="/static/images/trainer-5.svg",
        ),
    ]
    db.session.add_all(trainers)
    db.session.flush()
    return trainers


def create_classes(trainers):
    now = datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(days=1)
    classes = [
        FitnessClass(
            title="Boxing Fundamentals",
            class_type="Boxing",
            trainer_id=trainers[0].id,
            difficulty_level="Beginner",
            scheduled_at=now,
            duration_minutes=60,
            capacity=18,
            description="An introduction to stance, movement, and controlled conditioning rounds.",
        ),
        FitnessClass(
            title="Strength Lab",
            class_type="Strength Training",
            trainer_id=trainers[1].id,
            difficulty_level="Intermediate",
            scheduled_at=now + timedelta(hours=3),
            duration_minutes=75,
            capacity=16,
            description="Guided compound lifts with progressive overload and coaching cues.",
        ),
        FitnessClass(
            title="Sunrise Flow",
            class_type="Yoga",
            trainer_id=trainers[2].id,
            difficulty_level="Beginner",
            scheduled_at=now + timedelta(days=1, hours=1),
            duration_minutes=50,
            capacity=20,
            description="Mobility-driven yoga to reset posture and build flexibility.",
        ),
        FitnessClass(
            title="HIIT Express",
            class_type="HIIT",
            trainer_id=trainers[3].id,
            difficulty_level="Advanced",
            scheduled_at=now + timedelta(days=1, hours=4),
            duration_minutes=45,
            capacity=14,
            description="Short intervals, hard effort, and fast-paced transitions for serious conditioning.",
        ),
        FitnessClass(
            title="Cardio Burn",
            class_type="Cardio",
            trainer_id=trainers[3].id,
            difficulty_level="Intermediate",
            scheduled_at=now + timedelta(days=2, hours=2),
            duration_minutes=55,
            capacity=22,
            description="Structured treadmill, bike, and bodyweight circuits to improve endurance.",
        ),
        FitnessClass(
            title="Core and Mobility",
            class_type="Mobility",
            trainer_id=trainers[2].id,
            difficulty_level="Beginner",
            scheduled_at=now + timedelta(days=3),
            duration_minutes=40,
            capacity=18,
            description="A recovery-focused class for posture, control, and movement quality.",
        ),
        FitnessClass(
            title="Functional Power",
            class_type="Functional Training",
            trainer_id=trainers[4].id,
            difficulty_level="Intermediate",
            scheduled_at=now + timedelta(days=3, hours=3),
            duration_minutes=60,
            capacity=15,
            description="Medicine balls, kettlebells, and athletic movement patterns.",
        ),
        FitnessClass(
            title="Weekend Warrior",
            class_type="Strength Training",
            trainer_id=trainers[1].id,
            difficulty_level="Advanced",
            scheduled_at=now + timedelta(days=5, hours=1),
            duration_minutes=80,
            capacity=12,
            description="Higher intensity strength blocks for experienced members.",
        ),
    ]
    db.session.add_all(classes)
    db.session.flush()
    return classes


def create_members(plans):
    members = []
    today = date.today()
    for index in range(10):
        plan = plans[index % len(plans)]
        start_date = today - timedelta(days=index * 3)
        members.append(
            Member(
                first_name=f"Member{index + 1}",
                last_name="Demo",
                email=f"member{index + 1}@ironfit.local",
                phone=f"+1 555 02{index:02d}",
                membership_plan_id=plan.id,
                start_date=start_date,
                end_date=start_date + timedelta(days=plan.duration_days),
                status="active" if index < 7 else "inactive",
            )
        )
    db.session.add_all(members)
    db.session.flush()
    return members


def create_bookings(classes):
    bookings = [
        Booking(
            fitness_class_id=classes[0].id,
            customer_name="Liam Carter",
            email="liam.carter@example.com",
            phone="+1 555 1001",
            message="First time trying boxing.",
            status="confirmed",
        ),
        Booking(
            fitness_class_id=classes[1].id,
            customer_name="Sophia Lewis",
            email="sophia.lewis@example.com",
            phone="+1 555 1002",
            message="Interested in strength progressions.",
            status="pending",
        ),
        Booking(
            fitness_class_id=classes[2].id,
            customer_name="Daniel Moore",
            email="daniel.moore@example.com",
            phone="+1 555 1003",
            message="Recovering from long study hours.",
            status="confirmed",
        ),
        Booking(
            fitness_class_id=classes[3].id,
            customer_name="Emily Green",
            email="emily.green@example.com",
            phone="+1 555 1004",
            message="Please confirm the equipment needed.",
            status="pending",
        ),
        Booking(
            fitness_class_id=classes[4].id,
            customer_name="Mason Scott",
            email="mason.scott@example.com",
            phone="+1 555 1005",
            message="Joining with a friend.",
            status="cancelled",
        ),
    ]
    db.session.add_all(bookings)
    db.session.flush()
    return bookings


with app.app_context():
    reset_database()
    plans = create_plans()
    trainers = create_trainers()
    classes = create_classes(trainers)
    create_members(plans)
    create_bookings(classes)
    db.session.commit()
    print("Seed data created successfully.")
