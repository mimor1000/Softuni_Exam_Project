from functools import wraps

from flask import (
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from .forms import (
    ActionForm,
    BookingForm,
    BookingStatusForm,
    FitnessClassForm,
    LoginForm,
    MemberForm,
    MembershipPlanForm,
    TrainerForm,
)
from .models import Booking, FitnessClass, Member, MembershipPlan, Trainer, dashboard_stats, db


ADMIN_SESSION_KEY = "is_admin_authenticated"


def admin_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if not session.get(ADMIN_SESSION_KEY):
            flash("Please sign in to access the admin area.", "warning")
            return redirect(url_for("admin_login", next=request.path))
        return view_func(*args, **kwargs)

    return wrapped_view


def populate_member_plan_choices(form):
    form.membership_plan_id.choices = [
        (plan.id, plan.name)
        for plan in db.session.scalars(db.select(MembershipPlan).order_by(MembershipPlan.name))
    ]


def populate_trainer_choices(form):
    form.trainer_id.choices = [
        (trainer.id, trainer.full_name)
        for trainer in db.session.scalars(db.select(Trainer).order_by(Trainer.first_name))
    ]


def class_filters():
    trainer_options = db.session.scalars(db.select(Trainer).order_by(Trainer.first_name)).all()
    selected_type = request.args.get("type", "").strip()
    selected_trainer = request.args.get("trainer", "").strip()
    selected_difficulty = request.args.get("difficulty", "").strip()
    spots_filter = request.args.get("spots", "").strip()

    query = db.select(FitnessClass).order_by(FitnessClass.scheduled_at)

    if selected_type:
        query = query.filter(FitnessClass.class_type.ilike(f"%{selected_type}%"))
    if selected_trainer.isdigit():
        query = query.filter(FitnessClass.trainer_id == int(selected_trainer))
    if selected_difficulty:
        query = query.filter(FitnessClass.difficulty_level == selected_difficulty)

    classes = db.session.scalars(query).all()
    if spots_filter == "available":
        classes = [fitness_class for fitness_class in classes if fitness_class.available_spots > 0]

    class_types = sorted(
        {
            class_type
            for class_type in db.session.scalars(db.select(FitnessClass.class_type).distinct())
            if class_type
        }
    )
    difficulties = sorted(
        {
            difficulty
            for difficulty in db.session.scalars(
                db.select(FitnessClass.difficulty_level).distinct()
            )
            if difficulty
        }
    )

    return classes, trainer_options, class_types, difficulties


def save_and_redirect(entity_name, endpoint):
    db.session.commit()
    flash(f"{entity_name} saved successfully.", "success")
    return redirect(url_for(endpoint))


def register_routes(app):
    @app.route("/")
    def index():
        plans = db.session.scalars(
            db.select(MembershipPlan).order_by(MembershipPlan.price).limit(3)
        ).all()
        trainers = db.session.scalars(db.select(Trainer).order_by(Trainer.first_name).limit(3)).all()
        classes = db.session.scalars(
            db.select(FitnessClass).order_by(FitnessClass.scheduled_at).limit(4)
        ).all()
        return render_template(
            "index.html",
            plans=plans,
            trainers=trainers,
            classes=classes,
            testimonials=[
                {
                    "name": "Sara Kim",
                    "quote": "IronFit helped me build consistency without feeling overwhelmed.",
                },
                {
                    "name": "Omar Patel",
                    "quote": "The coaching and class schedule make this gym easy to stick with.",
                },
            ],
        )

    @app.route("/plans")
    def plans():
        all_plans = db.session.scalars(db.select(MembershipPlan).order_by(MembershipPlan.price)).all()
        return render_template("plans.html", plans=all_plans)

    @app.route("/trainers")
    def trainers():
        all_trainers = db.session.scalars(db.select(Trainer).order_by(Trainer.first_name)).all()
        return render_template("trainers.html", trainers=all_trainers)

    @app.route("/classes")
    def classes():
        filtered_classes, trainer_options, class_types, difficulties = class_filters()
        return render_template(
            "classes.html",
            classes=filtered_classes,
            trainer_options=trainer_options,
            class_types=class_types,
            difficulties=difficulties,
        )

    @app.route("/classes/<int:class_id>")
    def class_detail(class_id):
        fitness_class = db.get_or_404(FitnessClass, class_id)
        return render_template("class_detail.html", fitness_class=fitness_class)

    @app.route("/book/<int:class_id>", methods=["GET", "POST"])
    def book_class(class_id):
        fitness_class = db.get_or_404(FitnessClass, class_id)
        form = BookingForm()
        if form.validate_on_submit():
            if fitness_class.available_spots <= 0:
                flash("This class is fully booked.", "danger")
                return redirect(url_for("classes"))
            booking = Booking(
                fitness_class_id=fitness_class.id,
                customer_name=form.customer_name.data,
                email=form.email.data,
                phone=form.phone.data,
                message=form.message.data,
            )
            db.session.add(booking)
            db.session.commit()
            flash("Your booking has been received.", "success")
            return redirect(url_for("class_detail", class_id=fitness_class.id))
        return render_template("booking.html", form=form, fitness_class=fitness_class)

    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        form = LoginForm()
        if form.validate_on_submit():
            if (
                form.username.data == app.config["ADMIN_USERNAME"]
                and form.password.data == app.config["ADMIN_PASSWORD"]
            ):
                session[ADMIN_SESSION_KEY] = True
                flash("Signed in successfully.", "success")
                next_url = request.args.get("next")
                return redirect(next_url or url_for("admin_dashboard"))
            flash("Invalid credentials.", "danger")
        return render_template("admin/login.html", form=form)

    @app.post("/admin/logout")
    def admin_logout():
        form = ActionForm()
        if not form.validate_on_submit():
            abort(400)
        session.pop(ADMIN_SESSION_KEY, None)
        flash("You have been signed out.", "info")
        return redirect(url_for("admin_login"))

    @app.route("/admin")
    @admin_required
    def admin_dashboard():
        stats = dashboard_stats()
        action_form = ActionForm()
        recent_bookings = db.session.scalars(
            db.select(Booking).order_by(Booking.submitted_at.desc()).limit(5)
        ).all()
        recent_members = db.session.scalars(
            db.select(Member).order_by(Member.created_at.desc()).limit(5)
        ).all()
        return render_template(
            "admin/dashboard.html",
            stats=stats,
            recent_bookings=recent_bookings,
            recent_members=recent_members,
            action_form=action_form,
        )

    @app.route("/admin/members")
    @admin_required
    def admin_members():
        action_form = ActionForm()
        members = db.session.scalars(db.select(Member).order_by(Member.created_at.desc())).all()
        return render_template("admin/members.html", members=members, action_form=action_form)

    @app.route("/admin/members/add", methods=["GET", "POST"])
    @admin_required
    def admin_member_add():
        form = MemberForm()
        populate_member_plan_choices(form)
        if form.validate_on_submit():
            member = Member(
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                email=form.email.data,
                phone=form.phone.data,
                membership_plan_id=form.membership_plan_id.data,
                start_date=form.start_date.data,
                end_date=form.end_date.data,
                status=form.status.data,
            )
            db.session.add(member)
            return save_and_redirect("Member", "admin_members")
        return render_template("admin/member_form.html", form=form, title="Add member")

    @app.route("/admin/members/<int:member_id>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_member_edit(member_id):
        member = db.get_or_404(Member, member_id)
        form = MemberForm(obj=member)
        populate_member_plan_choices(form)
        if form.validate_on_submit():
            form.populate_obj(member)
            return save_and_redirect("Member", "admin_members")
        return render_template("admin/member_form.html", form=form, title="Edit member")

    @app.post("/admin/members/<int:member_id>/delete")
    @admin_required
    def admin_member_delete(member_id):
        form = ActionForm()
        if not form.validate_on_submit():
            abort(400)
        member = db.get_or_404(Member, member_id)
        db.session.delete(member)
        db.session.commit()
        flash("Member deleted.", "info")
        return redirect(url_for("admin_members"))

    @app.route("/admin/trainers", methods=["GET", "POST"])
    @admin_required
    def admin_trainers():
        form = TrainerForm()
        action_form = ActionForm()
        if form.validate_on_submit():
            trainer = Trainer(
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                specialty=form.specialty.data,
                experience_years=form.experience_years.data,
                email=form.email.data,
                phone=form.phone.data,
                bio=form.bio.data,
                image_url=form.image_url.data,
            )
            db.session.add(trainer)
            return save_and_redirect("Trainer", "admin_trainers")
        trainers_list = db.session.scalars(db.select(Trainer).order_by(Trainer.first_name)).all()
        return render_template(
            "admin/trainers.html", form=form, trainers=trainers_list, action_form=action_form
        )

    @app.post("/admin/trainers/<int:trainer_id>/delete")
    @admin_required
    def admin_trainer_delete(trainer_id):
        form = ActionForm()
        if not form.validate_on_submit():
            abort(400)
        trainer = db.get_or_404(Trainer, trainer_id)
        db.session.delete(trainer)
        db.session.commit()
        flash("Trainer deleted.", "info")
        return redirect(url_for("admin_trainers"))

    @app.route("/admin/plans", methods=["GET", "POST"])
    @admin_required
    def admin_plans():
        form = MembershipPlanForm()
        action_form = ActionForm()
        if form.validate_on_submit():
            plan = MembershipPlan(
                name=form.name.data,
                price=float(form.price.data),
                duration_days=form.duration_days.data,
                description=form.description.data,
                benefits=form.benefits.data,
            )
            db.session.add(plan)
            return save_and_redirect("Membership plan", "admin_plans")
        plans_list = db.session.scalars(db.select(MembershipPlan).order_by(MembershipPlan.price)).all()
        return render_template(
            "admin/plans.html", form=form, plans=plans_list, action_form=action_form
        )

    @app.post("/admin/plans/<int:plan_id>/delete")
    @admin_required
    def admin_plan_delete(plan_id):
        form = ActionForm()
        if not form.validate_on_submit():
            abort(400)
        plan = db.get_or_404(MembershipPlan, plan_id)
        if plan.members:
            flash("Cannot delete a plan that is assigned to members.", "danger")
            return redirect(url_for("admin_plans"))
        db.session.delete(plan)
        db.session.commit()
        flash("Membership plan deleted.", "info")
        return redirect(url_for("admin_plans"))

    @app.route("/admin/classes", methods=["GET", "POST"])
    @admin_required
    def admin_classes():
        form = FitnessClassForm()
        action_form = ActionForm()
        populate_trainer_choices(form)
        if form.validate_on_submit():
            fitness_class = FitnessClass(
                title=form.title.data,
                class_type=form.class_type.data,
                trainer_id=form.trainer_id.data,
                difficulty_level=form.difficulty_level.data,
                scheduled_at=form.scheduled_at.data,
                duration_minutes=form.duration_minutes.data,
                capacity=form.capacity.data,
                description=form.description.data,
            )
            db.session.add(fitness_class)
            return save_and_redirect("Fitness class", "admin_classes")
        classes_list = db.session.scalars(
            db.select(FitnessClass).order_by(FitnessClass.scheduled_at)
        ).all()
        return render_template(
            "admin/classes.html", form=form, classes=classes_list, action_form=action_form
        )

    @app.post("/admin/classes/<int:class_id>/delete")
    @admin_required
    def admin_class_delete(class_id):
        form = ActionForm()
        if not form.validate_on_submit():
            abort(400)
        fitness_class = db.get_or_404(FitnessClass, class_id)
        db.session.delete(fitness_class)
        db.session.commit()
        flash("Fitness class deleted.", "info")
        return redirect(url_for("admin_classes"))

    @app.route("/admin/bookings", methods=["GET", "POST"])
    @admin_required
    def admin_bookings():
        status_form = BookingStatusForm()
        action_form = ActionForm()
        booking_id = request.form.get("booking_id", type=int)
        if status_form.validate_on_submit() and booking_id:
            booking = db.get_or_404(Booking, booking_id)
            booking.status = status_form.status.data
            db.session.commit()
            flash("Booking updated.", "success")
            return redirect(url_for("admin_bookings"))
        bookings = db.session.scalars(db.select(Booking).order_by(Booking.submitted_at.desc())).all()
        return render_template(
            "admin/bookings.html",
            bookings=bookings,
            status_form=status_form,
            action_form=action_form,
        )

    @app.errorhandler(404)
    def not_found(error):
        return render_template("404.html"), 404

    @app.errorhandler(500)
    def server_error(error):
        db.session.rollback()
        return render_template("500.html"), 500
