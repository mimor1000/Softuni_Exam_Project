from flask_wtf import FlaskForm
from wtforms import (
    DateField,
    DateTimeLocalField,
    IntegerField,
    PasswordField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
)
from wtforms.fields import DecimalField
from wtforms.validators import DataRequired, Email, Length, NumberRange, Optional


STATUS_CHOICES = [("active", "Active"), ("inactive", "Inactive"), ("expired", "Expired")]
BOOKING_STATUS_CHOICES = [
    ("pending", "Pending"),
    ("confirmed", "Confirmed"),
    ("cancelled", "Cancelled"),
]
DIFFICULTY_CHOICES = [
    ("Beginner", "Beginner"),
    ("Intermediate", "Intermediate"),
    ("Advanced", "Advanced"),
]


class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(max=80)])
    password = PasswordField("Password", validators=[DataRequired(), Length(max=120)])
    submit = SubmitField("Sign in")


class BookingForm(FlaskForm):
    customer_name = StringField("Full name", validators=[DataRequired(), Length(max=120)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Phone", validators=[DataRequired(), Length(max=30)])
    message = TextAreaField("Message", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Book class")


class MemberForm(FlaskForm):
    first_name = StringField("First name", validators=[DataRequired(), Length(max=80)])
    last_name = StringField("Last name", validators=[DataRequired(), Length(max=80)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Phone", validators=[DataRequired(), Length(max=30)])
    membership_plan_id = SelectField("Membership plan", coerce=int, validators=[DataRequired()])
    start_date = DateField("Start date", validators=[DataRequired()])
    end_date = DateField("End date", validators=[DataRequired()])
    status = SelectField("Status", choices=STATUS_CHOICES, validators=[DataRequired()])
    submit = SubmitField("Save member")


class MembershipPlanForm(FlaskForm):
    name = StringField("Plan name", validators=[DataRequired(), Length(max=120)])
    price = DecimalField("Price", validators=[DataRequired(), NumberRange(min=0)])
    duration_days = IntegerField(
        "Duration (days)", validators=[DataRequired(), NumberRange(min=1)]
    )
    description = TextAreaField("Description", validators=[DataRequired(), Length(max=600)])
    benefits = TextAreaField("Benefits", validators=[DataRequired(), Length(max=600)])
    submit = SubmitField("Save plan")


class TrainerForm(FlaskForm):
    first_name = StringField("First name", validators=[DataRequired(), Length(max=80)])
    last_name = StringField("Last name", validators=[DataRequired(), Length(max=80)])
    specialty = StringField("Specialty", validators=[DataRequired(), Length(max=120)])
    experience_years = IntegerField(
        "Experience (years)", validators=[DataRequired(), NumberRange(min=0)]
    )
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Phone", validators=[DataRequired(), Length(max=30)])
    bio = TextAreaField("Bio", validators=[DataRequired(), Length(max=700)])
    image_url = StringField("Image URL", validators=[DataRequired(), Length(max=255)])
    submit = SubmitField("Save trainer")


class FitnessClassForm(FlaskForm):
    title = StringField("Class title", validators=[DataRequired(), Length(max=120)])
    class_type = StringField("Class type", validators=[DataRequired(), Length(max=80)])
    trainer_id = SelectField("Trainer", coerce=int, validators=[DataRequired()])
    difficulty_level = SelectField(
        "Difficulty", choices=DIFFICULTY_CHOICES, validators=[DataRequired()]
    )
    scheduled_at = DateTimeLocalField(
        "Scheduled at", format="%Y-%m-%dT%H:%M", validators=[DataRequired()]
    )
    duration_minutes = IntegerField(
        "Duration (minutes)", validators=[DataRequired(), NumberRange(min=15)]
    )
    capacity = IntegerField("Capacity", validators=[DataRequired(), NumberRange(min=1)])
    description = TextAreaField("Description", validators=[DataRequired(), Length(max=700)])
    submit = SubmitField("Save class")


class BookingStatusForm(FlaskForm):
    status = SelectField("Status", choices=BOOKING_STATUS_CHOICES, validators=[DataRequired()])
    submit = SubmitField("Update")


class ActionForm(FlaskForm):
    submit = SubmitField("Confirm")
