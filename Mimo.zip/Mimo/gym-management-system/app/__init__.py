from pathlib import Path

from flask import Flask
from flask_wtf.csrf import CSRFProtect

from config import Config
from .models import db

csrf = CSRFProtect()


def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)

    Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    csrf.init_app(app)

    from .routes import register_routes

    register_routes(app)

    with app.app_context():
        db.create_all()

    return app
