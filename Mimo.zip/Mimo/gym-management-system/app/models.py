from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func


db = SQLAlchemy()


class MembershipPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True)
    price = db.Column(db.Float, nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=False)
    benefits = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    members = db.relationship("Member", back_populates="membership_plan", lazy=True)

    @property
    def benefit_list(self):
        return [item.strip() for item in self.benefits.split("\n") if item.strip()]


class Trainer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    specialty = db.Column(db.String(120), nullable=False)
    experience_years = db.Column(db.Integer, nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    phone = db.Column(db.String(30), nullable=False)
    bio = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(255), nullable=False)

    classes = db.relationship("FitnessClass", back_populates="trainer", lazy=True)

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class FitnessClass(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    class_type = db.Column(db.String(80), nullable=False)
    trainer_id = db.Column(db.Integer, db.ForeignKey("trainer.id"), nullable=False)
    difficulty_level = db.Column(db.String(40), nullable=False)
    scheduled_at = db.Column(db.DateTime, nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=False)

    trainer = db.relationship("Trainer", back_populates="classes")
    bookings = db.relationship(
        "Booking", back_populates="fitness_class", cascade="all, delete-orphan", lazy=True
    )

    @property
    def booked_spots(self):
        return sum(1 for booking in self.bookings if booking.status != "cancelled")

    @property
    def available_spots(self):
        return max(self.capacity - self.booked_spots, 0)


class Member(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    phone = db.Column(db.String(30), nullable=False)
    membership_plan_id = db.Column(
        db.Integer, db.ForeignKey("membership_plan.id"), nullable=False
    )
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="active")
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    membership_plan = db.relationship("MembershipPlan", back_populates="members")

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fitness_class_id = db.Column(
        db.Integer, db.ForeignKey("fitness_class.id"), nullable=False
    )
    customer_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    message = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="pending")
    submitted_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    fitness_class = db.relationship("FitnessClass", back_populates="bookings")


def dashboard_stats():
    return {
        "members": db.session.scalar(db.select(func.count(Member.id))) or 0,
        "trainers": db.session.scalar(db.select(func.count(Trainer.id))) or 0,
        "plans": db.session.scalar(db.select(func.count(MembershipPlan.id))) or 0,
        "classes": db.session.scalar(db.select(func.count(FitnessClass.id))) or 0,
        "bookings": db.session.scalar(db.select(func.count(Booking.id))) or 0,
    }
